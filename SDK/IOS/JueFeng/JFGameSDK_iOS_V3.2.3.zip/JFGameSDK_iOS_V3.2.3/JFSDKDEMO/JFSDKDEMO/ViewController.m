//
//  JFGameSDKLogon.h
//  JFGAMESDK
//
//  Created by 董君龙 on 2021/12/24.
//  Copyright © 2021 绝峰. All rights reserved.
//
#import "ViewController.h"
#import <JFGAMESDK/JFGAMESDK.h>


@interface ViewController ()<JFGameSDKDelegate>

@property(nonatomic,strong) UITextField *textField;

@property(nonatomic,strong)UIView *BPhoneNumberView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    //横屏
//    [self forceToOrientation:UIDeviceOrientationLandscapeRight];
    //竖屏
    [self forceToOrientation:UIDeviceOrientationPortrait];
    
    self.BPhoneNumberView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    self.BPhoneNumberView.backgroundColor = [UIColor darkGrayColor];
    [self.view addSubview:self.BPhoneNumberView];
    
    UIButton * button1 = [[UIButton alloc]init];
    button1.frame = CGRectMake(self.view.frame.size.width/2-75, 20, 150, 50);
    button1.backgroundColor = [UIColor redColor];
    button1.tag = 1;
    [button1 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button1 setTitle:@"登录" forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button1.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button1];

    
    UIButton * button2 = [[UIButton alloc]init];
    button2.frame = CGRectMake(self.view.frame.size.width/2-75, 70+10, 150, 50);
    button2.backgroundColor = [UIColor blueColor];
    button2.tag = 2;
    [button2 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button2 setTitle:@"支付" forState:UIControlStateNormal];
    [button2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button2.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button2];
    
    UIButton * button3 = [[UIButton alloc]init];
    button3.frame = CGRectMake(self.view.frame.size.width/2-75, 130+10, 150, 50);
    button3.backgroundColor = [UIColor orangeColor];
    button3.tag = 3;
    [button3 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button3 setTitle:@"同步数据" forState:UIControlStateNormal];
    [button3 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button3.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button3];
    
    UIButton * button4 = [[UIButton alloc]init];
    button4.frame = CGRectMake(self.view.frame.size.width/2-75, 190+10, 150, 50);
    button4.backgroundColor = [UIColor greenColor];
    button4.tag = 4;
    [button4 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button4 setTitle:@"退出" forState:UIControlStateNormal];
    [button4 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button4.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button4];
    
    UIButton * button5 = [[UIButton alloc]init];
    button5.frame = CGRectMake(self.view.frame.size.width/2-75, 250+10, 150, 50);
    button5.backgroundColor = [UIColor cyanColor];
    button5.tag = 5;
    [button5 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button5 setTitle:@"切换账号" forState:UIControlStateNormal];
    [button5 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button5.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button5];
    
    
    
    UIButton * button6 = [[UIButton alloc]init];
    button6.frame = CGRectMake(self.view.frame.size.width/2-75, 310+10, 150, 50);
    button6.backgroundColor = [UIColor blackColor];
    button6.tag = 6;
    [button6 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button6 setTitle:@"活动入口" forState:UIControlStateNormal];
    [button6 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button6.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button6];
    
    self.textField = [[UITextField alloc] initWithFrame:CGRectMake(10, 310+10, 80, 50)];
    [self.textField setTextAlignment:NSTextAlignmentCenter];
    self.textField.keyboardType = UIKeyboardTypePhonePad;
    self.textField.returnKeyType = UIReturnKeyDone;
    self.textField.font = [UIFont systemFontOfSize:18];
    self.textField.backgroundColor = [UIColor clearColor];
    self.textField.textColor = [UIColor blackColor];
    self.textField.borderStyle = UITextBorderStyleLine;
    self.textField.backgroundColor = [UIColor whiteColor];
    [self.BPhoneNumberView addSubview:self.textField];
    
    
    UIButton * button7 = [[UIButton alloc]init];
    button7.frame = CGRectMake(self.view.frame.size.width/2-75, 370+10, 150, 50);
    button7.backgroundColor = [UIColor purpleColor];
    button7.tag = 7;
    [button7 addTarget:self action:@selector(BPhoneNumberBtn:) forControlEvents:UIControlEventTouchUpInside];
    [button7 setTitle:@"商城入口" forState:UIControlStateNormal];
    [button7 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button7.layer setCornerRadius:5.0];
    [self.BPhoneNumberView addSubview:button7];
}

#pragma mark - SDK最新版本：V3.2.0
#pragma mark - **************************SDK接口调用示例**************************

- (void)BPhoneNumberBtn:(UIButton *)button
{
    if (button.tag == 1) {
        NSLog(@"**************************JFGameSDK开始登录**************************");

        [[JFGameSDK shareInstance]logonWithController:self isAutoLogon:YES delegate:self];
        
    }else if (button.tag == 2) {
        
        JFGameSDKGameRoleInfo *roleInfo = [[JFGameSDKGameRoleInfo alloc] init];
        JFGameSDKPayOrderInfo *orderInfo = [[JFGameSDKPayOrderInfo alloc] init];
        //角色信息
        roleInfo.serverId = @"160";
        roleInfo.serverName = @"众神远征";
        roleInfo.gameRoleName = @"沧桑湘君";
        roleInfo.gameRoleID = @"16000001000383";
        roleInfo.gameUserBalance = @"0";
        roleInfo.vipLevel = @"0";
        roleInfo.gameUserLevel = @"1";
        roleInfo.partyName = @"";
        roleInfo.creatTime = @"1580105921";
        roleInfo.gameAreaId = @"150";
        roleInfo.fightPower = @"10000";
        roleInfo.profession = @"法师";

        
        //订单信息
        orderInfo.goodsID = @"348";
        orderInfo.productName = @"10000钻石";
        orderInfo.cpOrderID = @"160-2112261608911744193"; //必填 游戏订单号
        orderInfo.count = 1;  //必填 数量
        orderInfo.amount = @"0.01"; //必填 总价
        orderInfo.productDesc = @"10000钻石";
        orderInfo.callbackUrl = @"http://dl-as.hotgamehl.com/hotgame/kd/newsdk/router/h/85OAL7mxxgtBYM4o/m/pay/s/552/p/85/f/pay/";
        orderInfo.extrasParams = @"160-2112261608911744193";
        orderInfo.price = 10.00;
        orderInfo.quantifier = @"";
        orderInfo.remarkInfo = @"160-2112261608911744193";

        
        NSLog(@"**************************JFGameSDK开始拉起支付**************************roleInfo:%@,orderInfo:%@",roleInfo,orderInfo);
        
        [[JFGameSDK shareInstance]payWithOrderInfo:orderInfo roleInfo:roleInfo delegate:self];

    }else if (button.tag == 3) {
        
        JFGameSDKGameRoleInfo *gameRoleInfo = [[JFGameSDKGameRoleInfo alloc]init];
        gameRoleInfo.serverId = @"160";
        gameRoleInfo.serverName = @"众神远征";
        gameRoleInfo.gameRoleName = @"沧桑湘君";
        gameRoleInfo.gameRoleID = @"16000001000383";
        gameRoleInfo.gameUserBalance = @"0";
        gameRoleInfo.vipLevel = @"0";
        gameRoleInfo.gameUserLevel = @"1";
        gameRoleInfo.partyName = @"";
        gameRoleInfo.creatTime = @"1580105921";
        gameRoleInfo.gameAreaId = @"150";
        gameRoleInfo.fightPower = @"10000";
        gameRoleInfo.profession = @"法师";
        gameRoleInfo.type = @"1"
        
        NSLog(@"**************************JFGameSDK开始更新角色数据**************************gameRoleInfo:%@",gameRoleInfo);
        
        [[JFGameSDK shareInstance]updateWithRoleInfo:gameRoleInfo];
    }else if (button.tag == 4){
        
        NSLog(@"**************************JFGameSDK开始退出登录**************************");
        [[JFGameSDK shareInstance]logoutWithController:self delegate:self];

    }else if (button.tag == 5){
        
        NSLog(@"**************************JFGameSDK开始切换账号**************************");
        [[JFGameSDK shareInstance]switchAccountWithController:self delegate:self];
   
    }else if (button.tag == 6){
        
        NSLog(@"**************************JFGameSDK开始拉起活动页面**************************");
        [[JFGameSDK shareInstance]openActPageWithController:self
                                                    entryId:self.textField.text
                                                  entryType:@"one"
                                                 showScreen:@"2"
                                                   delegate:self];
    }else{
        NSLog(@"**************************JFGameSDK开始拉起小7商城**************************");

        JFGameSDKX7MallRoleInfo *X7MallRoleInfo = [[JFGameSDKX7MallRoleInfo alloc]init];
        //必填参数必须赋值，且不能为空字符串
        X7MallRoleInfo.game_role_name = @"我的名称";
        X7MallRoleInfo.game_role_id = @"1";
        X7MallRoleInfo.game_guid = @"123";
        X7MallRoleInfo.game_area = @"一区";
        X7MallRoleInfo.game_area_id = @"-1";
        
        //以下参数也是必传，因为没有就做不了对应的活动；如果游戏没有某项数据，字段值留空并向对接人员说明。
        X7MallRoleInfo.roleCE = @"";//战力
        X7MallRoleInfo.roleLevel = @"";//角色等级
        X7MallRoleInfo.roleStage = @"";//角色关卡
        X7MallRoleInfo.roleRechargeAmount = @"";//角色充值

        [[JFGameSDK shareInstance]openWithX7MallRoleInfo:X7MallRoleInfo delegate:self];
    }
}


//登录回调（必接）
- (void)onLoginSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK登录成功**************************%@",success);
}

- (void)onLoginFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK登录失败**************************%@",failure);
}


//创建订单回调（必接）
- (void)onCreatedOrderSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK创建订单成功**************************%@",success);
}

- (void)onCreatedOrderFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK创建订单失败**************************%@",failure);
}


//支付回调（必接）
- (void)onPaySuccessCallback:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK支付成功**************************%@",success);
}

- (void)onPayFaildCallback:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK支付失败**************************%@",failure);
}


//退出回调（可选）
- (void)onLogoutLoginSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK退出成功**************************%@",success);
}

- (void)onLogoutLoginFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK退出失败**************************%@",failure);
}


//切换账号回调（可选）
-(void)onSwitchAccountSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK切换账号成功**************************%@",success);
}

- (void)onSwitchAccountFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK切换账号失败**************************%@",failure);
}


//活动回调（可选）
//注意：此接口回调成功后需要拉起游戏支付页面
-(void)openRechargePageSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK拉起活动页面成功**************************%@",success);
}

-(void)openRechargePageFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK拉起活动页面失败**************************%@",failure);
}


//小7商城回调（可选）
- (void)openWithX7MallSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK拉起小7商城成功**************************%@",success);
}

- (void)openWithX7MallFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK拉起小7商城失败**************************%@",failure);
}




#pragma mark -
#pragma mark - **************************SDK横竖屏设置**************************

-(BOOL)shouldAutorotate{
    return YES;
}


- (void)forceToOrientation:(UIDeviceOrientation)orientation
{
    NSNumber *orientationUnknown = [NSNumber numberWithInt:0];
    [[UIDevice currentDevice] setValue:orientationUnknown forKey:@"orientation"];

    NSNumber *orientationTarget = [NSNumber numberWithInt:orientation];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];
}

//强制竖屏,对应活动入口参数showScreen=1
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

//强制横屏，对应活动入口参数showScreen=2
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
//    return UIInterfaceOrientationLandscapeRight;
//}
//
//- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
//    return UIInterfaceOrientationMaskLandscapeRight;
//}


//点击空白隐藏键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.textField resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
