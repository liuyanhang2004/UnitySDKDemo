
/**
 游戏ID：
 81205
 server_key(服务器端KEY)：
 1F9A13ECF1554762D54F149286D8AD48

 app_key(游戏KEY)：
 1F9A13ECF1554762D54F149286D8AD48
 */
////项目参数
#define APPKEY    @"1F9A13ECF1554762D54F149286D8AD48"
#define APPID     @"81205"

#import "AppDelegate.h"
#import <JFGAMESDK/JFGAMESDK.h>
#import "ABCReachability.h"


@interface AppDelegate ()<JFGameSDKDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    /**
     网络监测
     注意：国行手机首次安装时会出现网络权限弹框，此处有短暂网络断开，会造成初始化失败，无法进入游戏
     故此处必须进行网络监测，有网络的时候再进行初始化
     */
    
    //可以使用多种方式初始化
    ABCReachability *reach = [ABCReachability reachabilityWithHostName:@"www.hcios.com"];
    //通知中心注册通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:ABCkReachabilityChangedNotification object:nil];
    //Reachability实例调用startNotifier方法启动网络状态监测
    [reach startNotifier];
    
    return YES;
}

//网络监测回调（必接）
- (void)reachabilityChanged:(NSNotification *)notification {
    ABCReachability *reach = [notification object];
    
    if (![reach isReachable]) {
        NSLog(@"无网络连接");
    } else {
        NSLog(@"网络已连接");
        //初始化
        JFGameSDKInitConfigure *configure = [[JFGameSDKInitConfigure alloc] init];
        configure.appId = APPID;
        configure.appKey = APPKEY;
        [[JFGameSDK shareInstance]initWithConfig:configure delegate:self];
        
    }
}

/**
 {
     code = 1;
     msg = "\U521d\U59cb\U5316\U6210\U529f";
 }
 */

//初始化回调（必接）
- (void)onInitSuccess:(NSDictionary *)success{
    NSLog(@"**************************JFGameSDK初始化成功**************************%@",success);
}

- (void)onInitFailure:(NSDictionary *)failure{
    NSLog(@"**************************JFGameSDK初始化失败**************************%@",failure);
}



//生命周期（必接）
- (void)applicationWillResignActive:(UIApplication *)application {
    
    [[JFGameSDK shareInstance] applicationWillResignActive:application];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    
    [[JFGameSDK shareInstance] applicationDidEnterBackground:application];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[JFGameSDK shareInstance] applicationWillEnterForeground:application];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[JFGameSDK shareInstance] applicationDidBecomeActive:application];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    [[JFGameSDK shareInstance] applicationWillTerminate:application];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error{
    [[JFGameSDK shareInstance] application:application didFailToRegisterForRemoteNotificationsWithError:error];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
    [[JFGameSDK shareInstance] application:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    [[JFGameSDK shareInstance] application:application didReceiveRemoteNotification:userInfo];
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window{
    
    return [[JFGameSDK shareInstance] application:application supportedInterfaceOrientationsForWindow:window];

}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler{
    
    [[JFGameSDK shareInstance] application:application continueUserActivity:userActivity restorationHandler:restorationHandler];
    return YES;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{

    [[JFGameSDK shareInstance] openURL:url application:application];
    return YES;
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{

    [[JFGameSDK shareInstance] openURL:url sourceApplication:sourceApplication application:application annotation:annotation];
    return YES;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    
    [[JFGameSDK shareInstance] openURL:url application:app options:options];

    return YES;
}

@end
